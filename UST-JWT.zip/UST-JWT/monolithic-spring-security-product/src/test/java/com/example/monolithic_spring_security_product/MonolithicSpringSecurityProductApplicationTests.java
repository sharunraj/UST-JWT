package com.example.monolithic_spring_security_product;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MonolithicSpringSecurityProductApplicationTests {

	@Test
	void contextLoads() {
	}

}
