package com.example.monolithic_spring_security_product.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Data

@Entity
@Table(name = "user_details")
public class AuthUser{
    @Id
    @Column(name = "cred_id")
    private int Id;
    @Column(name = "cred_user")
    private String Name;

    @Column(name = "cred_password")
    private String  Password;

    @ManyToMany
    @JoinTable(name = "credential_role",
            joinColumns = @JoinColumn(name ="cred_id"),
            inverseJoinColumns = @JoinColumn(name = "role_id"))
    List<RolesEntity> allRoles;

}
