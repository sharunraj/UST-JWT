package com.example.monolithic_spring_security_product.service;

import com.example.monolithic_spring_security_product.entity.AuthUser;
import com.example.monolithic_spring_security_product.repository.AuthUserDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class CustomUserDetailsService implements UserDetailsService {
    @Autowired
    AuthUserDao authUserDao;
    @Override
    public UserDetails loadUserByUsername(String authName) throws UsernameNotFoundException {
        Optional<AuthUser> authUser = Optional.ofNullable(authUserDao.findByAuthName(authName));
        return authUser
                .map((userInfo)->new CustomUserDetails(userInfo.getName(), userInfo.getPassword(), userInfo.getAllRoles()))
                .orElseThrow(()-> new UsernameNotFoundException(authName + " not found"));
    }

}

