package com.example.monolithic_spring_security_product.repository;

import com.example.monolithic_spring_security_product.entity.AuthUser;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AuthUserDao extends JpaRepository<AuthUser,Integer> {
    AuthUser findByAuthName(String authName);
}
