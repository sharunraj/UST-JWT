package com.example.monolithic_spring_security_product.controller;

import com.example.monolithic_spring_security_product.entity.ProductEntity;
import com.example.monolithic_spring_security_product.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
public class ProductController {
    @Autowired
    ProductService productService;

    @PreAuthorize("hasAuthority('ROLE_USER')")
    @GetMapping("/products")
    public List<ProductEntity> getAllProducts(){
        return productService.getAllProducts();
    }

    @PreAuthorize("hasAuthority('ROLE_USER')")
    @GetMapping("/products/{pid}")
    public ProductEntity getAProduct(@PathVariable("pid") long pid){
        return productService.getAProduct(pid);
    }

    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    @PostMapping("/products")
    public ProductEntity addProduct(@RequestBody ProductEntity productEntity){
        return productService.addProduct(productEntity);
    }


}
