package com.example.monolithic_spring_security_product.service;

import com.example.monolithic_spring_security_product.entity.ProductEntity;
import com.example.monolithic_spring_security_product.repository.ProductRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductService {
    @Autowired
    ProductRepo productRepo;

    public List<ProductEntity> getAllProducts(){
        return productRepo.findAll();
    }

    public ProductEntity getAProduct(long prodId){
        return productRepo.findById(prodId).orElse(null);
    }

    public ProductEntity addProduct(ProductEntity productEntity){
        return productRepo.save(productEntity);
    }


}
