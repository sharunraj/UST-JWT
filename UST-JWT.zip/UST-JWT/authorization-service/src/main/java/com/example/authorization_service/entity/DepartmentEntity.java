package com.example.authorization_service.entity;

public class DepartmentEntity {

}
