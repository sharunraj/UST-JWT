package com.example.authorization_service.service;

import com.example.authorization_service.Dao.UserInfoDao;
import com.example.authorization_service.entity.UserInfoEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import java.util.Optional;

public class UserInfoUserDetailsService implements UserDetailsService {
    @Autowired
    UserInfoDao userInfoDao;
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Optional<UserInfoEntity> userInfoEntity = Optional.ofNullable(userInfoDao.findByUserName(username));
// but we have return UserDetails and not UserInfoEntity
        return userInfoEntity
                .map((userInfo)->new UserInfoUserDetails(userInfo.getName(), userInfo.getPassword(), userInfo.getAllRoles()))
                .orElseThrow(()-> new UsernameNotFoundException(username + " not found"));
    }

}
